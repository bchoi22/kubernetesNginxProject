# Learn Terraform - Provision an EKS Cluster

This repo is a companion repo to the [Provision an EKS Cluster learn guide](https://learn.hashicorp.com/terraform/kubernetes/provision-eks-cluster), containing
Terraform configuration files to provision an EKS cluster on AWS.

This project is a work-in-progress.  Although the 'kubectl get deployments' command works (it shows the nginx deployments in the kubernetes cluster and in a running state), the problem is that I'm still having an issue connecting the ALB to the private instances housing my eks cluster.  The ALB, although deployed, is not connecting to my target groups.  I believe the issue is that the NAT is not allocating the proper public ip for the private one.  One of the ways to address this is, I believe, is to break everything out to include defining the route tables.

To see the deployments for both search-api and graph-api, execute the following lines:

1. brew install awscli (make sure to install package manager, homebrew, if you're running into errors)

2. aws configure
AWS Access Key ID [None]: YOUR_AWS_ACCESS_KEY_ID
AWS Secret Access Key [None]: YOUR_AWS_SECRET_ACCESS_KEY
Default region name [None]: YOUR_AWS_REGION
Default output format [None]: json

3. mkdir myeksproject

4. Download and install myProject files into the directory myeksproject

5. cd learn-terraform-provision-eks-cluster

6. terraform init

7. terraform apply (in case you run into any host access errors, run this: terraform state rm module.eks.kubernetes_config_map.aws_auth.  Then try again).  

8. aws eks --region $(terraform output -raw region) update-kubeconfig --name $(terraform output -raw cluster_name) 
Do this to configure kubectl with your credentials

9. cd eks-nginx

10. terraform init

11. terraform apply (in case you run into kubeconfig issues regarding not finding the host, run this: terraform state rm module.eks.kubernetes_config_map.aws_auth.  Then try again).  

12. kubectl get deployments 
You should see, 
NAME         READY   UP-TO-DATE   AVAILABLE   AGE
search-api   2/2     2            2           15s
graph-api    2/2     2            2           15s


13. Still need to connect the ALB to NATs within the public subnets properly so that the search.altana.ai and graph.altana.ai hostnames can be reached.  TBD.  
   
